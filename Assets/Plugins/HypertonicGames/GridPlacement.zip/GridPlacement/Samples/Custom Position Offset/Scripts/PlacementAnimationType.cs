namespace Hypertonic.GridPlacement.Example.PositionOffsetDemo
{
    public enum PlacementAnimationType { NONE, ANIMATION_CURVE}
}

using UnityEngine;

namespace Hypertonic.GridPlacement.Example.CustomValidation
{
    public class Wall : MonoBehaviour
    {
        
    }
}
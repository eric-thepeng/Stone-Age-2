
namespace Hypertonic.GridPlacement.Enums
{
    public enum HighlightCellType { Color }
}
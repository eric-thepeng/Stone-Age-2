
namespace Hypertonic.GridPlacement.Enums
{
    public enum PlacementInvalidReason { NONE, OUTSIDE_GRID, OVERLAPPING_CELL, CUSTOM_VALIDATION_FALED }
}
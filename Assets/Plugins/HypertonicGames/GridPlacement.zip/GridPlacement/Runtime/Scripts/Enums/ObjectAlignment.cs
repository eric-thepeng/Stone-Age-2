
namespace Hypertonic.GridPlacement.Enums
{
    public enum ObjectAlignment { CENTER, UPPER_LEFT, UPPER_MIDDLE, UPPER_RIGHT, MIDDLE_RIGHT, BOTTOM_RIGHT, BOTTOM_MIDDLE, BOTTOM_LEFT, MIDDLE_LEFT }
}
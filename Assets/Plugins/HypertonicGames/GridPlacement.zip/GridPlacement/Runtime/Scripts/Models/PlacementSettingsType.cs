/// <summary>
/// Provides the different types of placement settings
/// </summary>
namespace Hypertonic.GridPlacement.Models
{
    public enum PlacementSettingsType { GRID_CELL, WORLD_POSITION }
}